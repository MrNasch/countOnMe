![OpenClassrooms Logo](https://lh3.googleusercontent.com/jHFLsk0a2IDpofZxpPhZNgOsydDD1dqbUZKfO_hwvexataXSPp0oHMDm5WJJkZ8WFLnNqtEiLRHGRRw=w2880-h1632)

This repository is the base code for [this project](https://openclassrooms.com/projects/ameliorer-une-application-existante) on openclassrooms.com.
It's part of OpenClassrooms' iOS path which can be found here.

# ZozorPlus
Students are supposed to clone or fork the repo and improve it. Their focus should be on the following aspects :
- Responsiveness
- Documentation
- MVC compliance
- Tests
- Bonus feature
