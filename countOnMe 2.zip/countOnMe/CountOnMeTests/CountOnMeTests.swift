//
//  CountOnMeTests.swift
//  CountOnMeTests
//
//  Created by Nasch on 22/01/2019.
//  Copyright © 2019 Ambroise Collon. All rights reserved.
//

import XCTest
@testable import CountOnMe

class CountOnMeTests: XCTestCase {
    func testGivenAppLaunchedWhenPressNumberButtonThenUpdateDisplay() {
        let calculator = Calculator()
        
        calculator.stringNumbers = ["0"]
            
        calculator.addNewNumber(1)
        
        XCTAssert(calculator.stringNumbers.enumerated() += 1 )
    }
}
