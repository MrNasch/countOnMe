//
//  ViewController.swift
//  CountOnMe
//
//  Created by Ambroise COLLON on 30/08/2016.
//  Copyright © 2016 Ambroise Collon. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var calculator = Calculator()
    
    // MARK: - Outlets

    @IBOutlet weak var textView: UITextView!
    @IBOutlet var numberButtons: [UIButton]!
    @IBOutlet var operators: [UIButton]!
    
    // MARK: - Action
    @IBAction func tappedOpButton(_ sender: UIButton) {
        switch sender.tag {
        case 11:
            minus()
        case 12:
            plus()
        case 13:
            divide()
        case 14:
            multiply()
        case 15:
            equal()
        default:
            break
        }
    }
    @IBAction func tappedNumberButton(_ sender: UIButton) {
        calculator.addNewNumber(sender.tag)
        updateDisplay()
    }
    func alerts() {
        if calculator.stringNumbers.count <= 0 {
            let alertVC = UIAlertController(title: "Zéro!", message: "Start a new operation", preferredStyle: .alert)
            alertVC.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
            self.present(alertVC, animated: true, completion: nil)
        } else if calculator.stringNumbers == ["0"]{
            let alertVC = UIAlertController(title: "Zéro!", message: "You cannot divide by zero", preferredStyle: .alert)
            alertVC.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
            self.present(alertVC, animated: true, completion: nil)
        } else {
            let alertVC = UIAlertController(title: "Zéro!", message: "Enter correct expression", preferredStyle: .alert)
            alertVC.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
            self.present(alertVC, animated: true, completion: nil)
        }
    }
    
    @IBAction func multiply() {
        do {
            try calculator.addOperator("*")
        } catch {
            alerts()
        }
    }
    
    @IBAction func divide() {
        do {
            try calculator.addOperator("/")
        } catch {
            alerts()
        }
    }

    @IBAction func plus() {
        do {
            try calculator.addOperator("+")
        } catch {
            alerts()
        }
    }

    @IBAction func minus() {
        do {
            try calculator.addOperator("-")
        } catch {
            alerts()
        }
    }

    @IBAction func equal() {
        updateDisplay()
        let total = calculator.calculateTotal()
        textView.text! = "\(total)"
        calculator.clear()
    }
    func updateDisplay() {
        var text = ""
        for (i, stringNumber) in calculator.stringNumbers.enumerated() {
            // Add operator
            if i > 0 {
                text += calculator.operators[i]
            }
            // Add number
            text += stringNumber
        }
        textView.text = text
    }
   
}
